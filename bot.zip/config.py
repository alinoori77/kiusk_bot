# Bot configuration
api_id =  23582747 
api_hash = "f50536557af37cd45f0b3ad8d74e2730"
bot_token = "6316641778:AAHC6tD2AOPBY5Z_K8i87woWtozFGrRBHhQ"
phone_number = "+989395240893"

SOURCE_CHANNEL = "akharinkhabar"
FIRST_TARGET_CHANNEL = "akharin_to_kiusk"
SECOND_TARGET_CHANNEL = "kiuskonline"

